.. humanize documentation master file, created by sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

humanize
-----------

.. automodule:: humanize
.. highlight:: sh

You can install humanize with pip::

    pip install humanize

You can fork humanize `from its git repository
<http://github.com/jmoiron/humanize/>`_::

    git clone https://github.com/jmoiron/humanize.git

.. highlight:: python
